##########################################
# File: __init__.py                      #
# Copyright Richard Stebbing 2014.       #
# Distributed under the MIT License.     #
# (See accompany file LICENSE or copy at #
#  http://opensource.org/licenses/MIT)   #
##########################################
from qpbo_alpha_expand import qpbo_alpha_expand
